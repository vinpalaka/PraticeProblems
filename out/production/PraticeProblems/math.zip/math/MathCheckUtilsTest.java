package math;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MathCheckUtilsTest {

    @Test
    void checkSum() {
        MathCheckUtils checkUtils = new MathCheckUtils();
        String value = checkUtils.checkSum(1, 4, 5, 9);
        assertEquals("Yes", value, "1 and 4 do not reach 5 and 9");

        System.out.println("===================================================================");

        value = checkUtils.checkSum(1, 4, 5, 14);
        assertEquals("Yes", value, "1 and 4 do not reach 5 and 14");

        System.out.println("===================================================================");

        value = checkUtils.checkSum(1, 4, 5, 8);
        assertEquals("No", value, "1 and 4 do not reach 5 and 8");

        System.out.println("===================================================================");

        value = checkUtils.checkSum(2, 7, 7, 15);
        assertEquals("No", value, "1 and 4 do not reach 5 and 8");
        System.out.println("===================================================================");

        value = checkUtils.checkSum(3, 12, 27, 39);
        assertEquals("Yes", value, "1 and 4 do not reach 5 and 8");

        System.out.println("===================================================================");

        value = checkUtils.checkSum(2, 3, 8, 11);
        assertEquals("Yes", value, "1 and 4 do not reach 8 and 11");

    }
}