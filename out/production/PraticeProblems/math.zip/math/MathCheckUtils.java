package math;

import java.util.LinkedList;

public class MathCheckUtils {
    /**
     * does (x1 + y1, y1) (x1, y1 +x1) can possibly equal (x2, y2)
     * @param x1
     * @param y1
     * @param x2
     * @param y2
     * @return
     */
    public String checkSum(int x1, int y1, int x2, int y2) {
        if(!isValid(x1, y1, x2, y2)) {
            return "No";
        } else {
            //This is where I check
            LinkedList<Point> queue = new LinkedList();
            queue.add(new Point(x1, y1));

            while(!queue.isEmpty()) {
                Point item = queue.remove();
                System.out.println(item);
                int newX = item.x + item.y;
                if(isValid(newX, item.y, x2, y2)) {
                    queue.add(new Point(newX, item.y));
                }
                int newY = item.x + item.y;
                if(isValid(item.x, newY, x2, y2)) {
                    queue.add(new Point(item.x, newY));
                }
                if(item.x == x2 && item.y == y2) {
                    return "Yes";
                }
            }
            return "No";
        }
    }

    private class Point {
        public int x;
        public int y;
        Point(int x, int y) {
            this.x = x;
            this.y = y;
        }


        @Override
        public String toString() {
            return "Point{" +
                    "x=" + x +
                    ", y=" + y +
                    '}';
        }
    }

    private boolean isValid(int x1, int y1, int x2, int y2) {//1,6,4,8
         return (x1 <= x2 && y1 <= y2) ||
                 (x1 == x2  && (x1 + y1) <= y2) ||
                 (y1 == y2 && (x1 + y1 <= x2));
    }
}
